---
name: cocuk-ge-algoritma
description: >-
  Bir çocuk (pediyatrik) gastroenteroloji/hepatoloji şikâyeti, semptomu, muayene
  bulgusu, laboratuvar veya görüntüleme anormalliği ya da hastalık adı verildiğinde
  onu uzman-düzeyi klinik algoritma formatında anlatır: tanım, mekanizma/şiddet,
  karar akışı, basamaklı tetkik, kırmızı bayraklar, DOZLU tedavi ve izlem.
  Tetikleyiciler: "X için algoritma yap", "şu şikâyeti anlat", "yaklaşım nedir",
  "aynı formatta yap" ya da yalnızca başlık adı (reflü, safralı kusma, rektal
  kanama, uzamış sarılık, transaminaz yüksekliği, hepatomegali, Crohn, pankreatit…).
  Hedef kitle çocuk gastroenteroloji uzmanıdır.
---

# Çocuk GE Algoritma (taşınabilir)

Her yerde çalışır (claude.ai sohbeti, Claude Code, depo olsun olmasın).

## Altın kurallar
1. **Hedef kitle uzmandır** → "pediatrik gastroenterolojiye/uzmana sevk et" YAZMA.
   Somut tanı, tetkik, **dozlu tedavi**, izlem ver; gerekiyorsa cerrahi / yoğun bakım /
   nakil gibi **somut eşik** yaz.
2. **Dozlar**: daima **mg/kg + maksimum**. Güncel kılavuz (Rome IV, ESPGHAN/NASPGHAN,
   ECCO, AAP, konuya özgü). Emin olmadığın dozu uydurma; "kılavuza göre doğrula" de.
3. **Türkçe**, kısa ve taranabilir. Kırmızı bayraklar eksiksiz.

## Zorunlu 7 bölüm (her yanıtta bu sırayla)
1. **Tanım ve ilk değerlendirme** — tanım/eşikler; öykü ve muayene ipuçları.
2. **Etiyoloji/mekanizma VEYA şiddet sınıflaması** — yaşa göre ayırıcı tanı.
3. **Karar akışı** — adım → karar (EVET/HAYIR dalları) → eylem; gerçek bir ağaç.
4. **Basamaklı tetkik** — tablo: basamak · hedef · testler.
5. **Kırmızı bayraklar** — acil/organik neden göstergeleri.
6. **Tedavi** — tablo: durum/ilaç · doz (mg/kg + maks) · not.
7. **İzlem ve yönetim ilkeleri.**
+ **Kaynaklar** (2–4 gerçek kılavuz) + kısa uyarı ("eğitim amaçlı; dozları doğrulayın").

## Çıktı modları
- **Varsayılan (sohbet):** 7 bölümü **markdown** ile ver — başlıklar, tablolar, karar
  akışı için girintili ok listesi (`→ EVET: … / → HAYIR: …`).
- **Belge/HTML istenirse:** `reference/sablon.md`'deki sınıflarla yalnızca
  `<div class="wrap">…</div>` gövdesi üret; tam sayfa için başa
  `assets/series_style.css` içeriğini (bir `<style>` bloğu) ve `<title>` ekle. Bu
  tek dosya tarayıcıda açılır; PDF için yazdır.
- **Bu depo (sunu-) açıksa:** belgeyi `docs/pediatrik-<slug>-algoritmasi.html` olarak
  kaydet, `python3 tools/build.py` çalıştır (index + app'e ekler), commit et.

## Kalite kontrol
Sevk dili yok · dozlar mg/kg + maks · 7 bölüm tam · kırmızı bayraklar tam · kaynaklar
gerçek · Türkçe.
